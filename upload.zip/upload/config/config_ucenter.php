<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'discuz');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`discuz`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'Udg8k6za3eQ026ff51y3t049N6YdNem9R1G8sfBfZdg8B4Fe94r5pfi1w0hby5A7');
define('UC_API', 'http://120.136.130.25/forum/upload/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>