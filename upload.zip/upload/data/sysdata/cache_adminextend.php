<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 7e47ac83260216606944c5a2a6084f86

$adminextend = array (
  0 => 'cloud.php',
);
?>