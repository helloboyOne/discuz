<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 984124f606d6f169c63e591aba08c6eb

$pluginsetting = array (
);
?>